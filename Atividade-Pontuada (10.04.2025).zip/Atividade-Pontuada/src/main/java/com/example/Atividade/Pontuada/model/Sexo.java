package com.example.Atividade.Pontuada.model;

public enum Sexo {
    MASCULINO,
    FEMININO
}
