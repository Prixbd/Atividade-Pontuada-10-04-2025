package com.example.Atividade.Pontuada.model;

public enum Setor {
    ENGENHARIA,
    SAUDE,
    JURIDICO
}
