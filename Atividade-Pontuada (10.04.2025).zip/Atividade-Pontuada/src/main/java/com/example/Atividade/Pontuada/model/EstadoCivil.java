package com.example.Atividade.Pontuada.model;

public enum EstadoCivil {
    SOLTEIRO,
    CASADO,
    SEPARADO,
    DIVORCIADO,
    VIUVO
}
