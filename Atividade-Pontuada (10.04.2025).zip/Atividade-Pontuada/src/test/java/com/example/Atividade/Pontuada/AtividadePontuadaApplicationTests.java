package com.example.Atividade.Pontuada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadePontuadaApplicationTests {

	@Test
	void contextLoads() {
	}

}
